package com.example.system_time

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
